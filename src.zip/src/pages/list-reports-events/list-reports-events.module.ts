import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListReportsEventsPage } from './list-reports-events';

@NgModule({
  declarations: [
    ListReportsEventsPage,
  ],
  imports: [
    IonicPageModule.forChild(ListReportsEventsPage),
  ],
})
export class ListReportsEventsPageModule {}
