import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EventsProvider } from '../../providers/events/events';
import { DetailReportEventPage } from '../detail-report-event/detail-report-event';

@IonicPage()
@Component({
  selector: 'page-list-reports-events',
  templateUrl: 'list-reports-events.html',
})
export class ListReportsEventsPage {

  myReports:any = []

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              private eventsProv: EventsProvider ) {
    
    this.eventsProv.getNews(true).then((data:any)=>{
      console.log(data)
      let i;
      for (i = 0; i < data.length; i++) {
        data[i].coords = `${data[i].latitud},${data[i].longitud}`
      }
      this.myReports = data
    }, (error)=>{
      console.error(error)
    })
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ListReportsEventsPage');
  }

  viewReport( report:any ){
    this.navCtrl.push(DetailReportEventPage, { report: report })
  }

}
