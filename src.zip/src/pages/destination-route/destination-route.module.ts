import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DestinationRoutePage } from './destination-route';

@NgModule({
  declarations: [
    DestinationRoutePage,
  ],
  imports: [
    IonicPageModule.forChild(DestinationRoutePage),
  ],
})
export class DestinationRoutePageModule {}
