import { Component, ViewChild, ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, ModalController } from 'ionic-angular';
import * as constants from '../../util/constants';
import { GoogleMapsProvider } from '../../providers/google-maps/google-maps';
import { EventsProvider } from '../../providers/events/events';
//import moment from 'moment';
import { SetAddressPage } from '../set-address/set-address';

@IonicPage()
@Component({
  selector: 'page-destination-route',
  templateUrl: 'destination-route.html',
})
export class DestinationRoutePage {
  
  @ViewChild('map') mapElement:ElementRef
  map: any;
  route: any;
  markerArray:any[] = [];
  routeOut: boolean;
  
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public platform: Platform,
              public googleMapsProv: GoogleMapsProvider,
              public eventsProv: EventsProvider,
              public modalCtrl: ModalController) {
    
    console.log(this.navParams.get('route'));
    this.route = this.navParams.get('route'); 
    this.routeOut = true

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DestinationRoutePage');
  }

  ngAfterViewInit(){
    this.loadMap();
  }
  
  //cargar mapa
  loadMap(){
    // ubicacion por defecto
    //console.log("current position: ", constants.locations.latitude, constants.locations.longitude)
    //let latLng = new google.maps.LatLng(constants.locations.latitude, constants.locations.longitude);
      
    // crear mapa
    this.map = this.googleMapsProv.create(this.mapElement.nativeElement, {
      center: this.route.start_location
    });
    
    //validar si entra por primera vez
    // si es true colo pone el marcador inicial
    // de lo contrario muestra la ruta con los 2 puntos y el resto de la informacin
    if(this.routeOut){
      this.markerArray[0] = this.googleMapsProv.addMarker({ 
        map: this.map, 
        position: this.route.start_location,
        icon: 'assets/imgs/marker_user_small.png'
      })
    }else{
      this.calcRoute();
    }

  }
  
  // calcular ruta
  calcRoute(){
    // Primero, borra cualquier markerArray existente
    // de cálculos anteriores.
    for (let i = 0; i < this.markerArray.length; i++) {
      this.markerArray[i].setMap(null);
    }
    
    // ejecuata un metdo del provider google maps
    // que le permite generar una informacion completa
    // de una ruta solo pasandole el inicio y fin
    this.googleMapsProv.directions({
      map: this.map,
      request: {
        origin: this.route.start_location,
        destination: this.route.end_location,
        travelMode: 'DRIVING'
      }
    }).then((directionResult:any) =>{
      //console.log(directionResult);
      //console.log(directionResult.routes[0].legs[0]);
      this.route = directionResult.routes[0].legs[0]
      //console.log(this.route)
      // modificar primer marcador
      this.markerArray[0] = this.googleMapsProv.addMarker({ 
        map: this.map, 
        position: this.route.start_location,
        icon: 'assets/imgs/marker_user_small.png'
      })
  
      // modificar segundo marcador
      this.markerArray[1] = this.googleMapsProv.addMarker({ 
        map: this.map, 
        position: this.route.end_location,
        icon: 'assets/imgs/marker_endpoint_small.png'
      })
    }, (error) => console.error(error))
  }
  
  // midificar direccion
  setAddress(setaddress:string) {
    const modal = this.modalCtrl.create(SetAddressPage, { direction: this.route, map: this.map, inputSelect: setaddress });
    modal.onDidDismiss(data => {
      if(data && typeof data == 'object'){        
        // console.log("setAddress ->");
        // console.log(data);
        this.routeOut = false
        this.route = data;
        this.calcRoute();
      } 
    });
    modal.present();
  }
}
