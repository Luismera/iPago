import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';


/**
 * Generated class for the SystemPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-system',
  templateUrl: 'system.html',
})
export class SystemPage {
  activityDetail:any=[];
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    console.log(this.navParams.get('activity'));
    this.activityDetail = this.navParams.get('activity'); 
  }

   

  ionViewDidLoad() {
    console.log('ionViewDidLoad SystemPage');
  }

}
