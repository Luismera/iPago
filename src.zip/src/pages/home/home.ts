import { Component } from '@angular/core';
import { NavController, Platform } from 'ionic-angular';
import { SecureAccessPage } from '../secure-access/secure-access';
import { ApplicationsProvider } from '../../providers/applications/applications';
import { ApplicationDetailPage } from '../application-detail/application-detail';
import * as Constants from '../../util/constants';
//import * as jQuery from "jquery";
import * as ProgressBar from "progressbar.js";
import { SecurityProvider } from '../../providers/security/security';
import { HelpersProvider } from '../../providers/helpers/helpers';
import { CallNumber } from '@ionic-native/call-number';
import { AuthProvider } from '../../providers/auth/auth';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  
  applications:any[] = []
  didUserHoldForThreeSeconds:number = 0;
  circle:any = null;
  isActive:boolean = false;
  textbutton:string = 'PANICO';
  public unregisterBackButtonAction: any;

  public progress: number = 0;

  // Interval function
  protected interval: any;
  
  constructor(public navCtrl: NavController,
              private applicationsProv: ApplicationsProvider,
              public securityProv: SecurityProvider,
              public helper: HelpersProvider,
              public platform:Platform,
              private callNumber: CallNumber,
              private authProv: AuthProvider) {

    this.applicationsProv.getApplications().subscribe(data => {
      console.log(data)
      this.applications = data;
    });

  }
  //evento cuando la pagina se carga 
  ionViewDidLoad() {
    console.log('ionViewDidLoad HomePage');
    this.initializeBackButtonCustomHandler();
    this.helper.getUserPosition();
    this.circle = new ProgressBar.Circle('#progress_button_panic', {
      color: '#ef0702',
      duration: 3000,
      easing: 'linear',
      strokeWidth: 6,
      trailColor: '#cccccc',
      trailWidth: 6
    });
    this.circle.animate(1, 
      {duration: 1}, 
      function(){ 
        console.log("end released") 
      });
  }

  onPress($event){
    this.isActive = !this.isActive; 
    const self = this;
    //console.log(this.isActive);
    if(this.isActive){
      this.textbutton = 'DETENER';
      this.circle.animate(0, 
        {duration: 3000}, 
        function(){
            //llamada a servicio para enviar la señal
            let userLocation = self.helper.getPosition();
            //console.log("**********************PANICOOOO************************")
            //console.log(Constants.imei, userLocation);           
            self.securityProv.setPanicButton(Constants.imei, userLocation).then( data => {
              //$event.preventDefault();
              self.resetButton();   
              self.helper.showAlert("Se envió el botón pánico","Aviso");
              //self.onPressUp($event);
            }).catch( error =>{
              //$event.preventDefault();
              self.resetButton();   
              self.helper.showAlert(error,"Aviso");
              //self.onPressUp($event);
            });
            
        }
      );
         
    }else{
      this.resetButton();
    }
  }
  

  resetButton(){
    const self = this;
    this.textbutton = 'PANICO';
    this.circle.animate(1, 
      {duration: 500}, 
      function(){ 
        console.log("reset") 
        self.isActive = false;
      }
    );
  }
  
  getApplication(app:any) {
    let self = this
    if (this.applicationsProv.hasDisableIntro(app.id)) {
      if (app.type === 'link') {
        self.helper.open(app.path);
      } else {
        this.helper.appIsInstalled(app.path, function(appIsInstall) {
          if (appIsInstall) {
            self.helper.appLaunch(app.path, function() {});
          } else {
            self.helper.open('https://play.google.com/store/apps/details?id=' + app.path);
          }
        });
      }
    } else {
      this.navCtrl.push(ApplicationDetailPage, { app: app })
    }
  };
  
  callCentral() {
    this.authProv.user.subscribe((user)=>{ 
      console.log(user)
      console.log(user.phone_central)
      this.callNumber.callNumber(user.phone_central, true)
                    .then(res => console.log('Launched dialer!', res))
                    .catch(err => console.error('Error launching dialer', err));
    })
   
  };
  
  accessSecure() {
    this.navCtrl.push(SecureAccessPage);
  };

  /* 
  // funcion se ejecuta cuando esta apunto de salir o ya no es la activa 
  
  */
  ionViewWillLeave() {
      // Unregister the custom back button action for this page
      this.unregisterBackButtonAction && this.unregisterBackButtonAction();
  }
  /* 
  // custom HANDLER for backbutton action
  */
  initializeBackButtonCustomHandler(): void {
      this.unregisterBackButtonAction = this.platform.registerBackButtonAction(function(event){
          console.log('Prevent Back Button Page Change');
      }, 101); // Priority 101 will override back button handling (we set in app.component.ts) as it is bigger then priority 100 configured in app.component.ts file */
  }  

}
