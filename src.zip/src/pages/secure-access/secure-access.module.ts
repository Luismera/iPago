import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SecureAccessPage } from './secure-access';

@NgModule({
  declarations: [
    SecureAccessPage,
  ],
  imports: [
    IonicPageModule.forChild(SecureAccessPage),
  ],
})
export class SecureAccessPageModule {}
