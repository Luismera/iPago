import { Component, ChangeDetectorRef } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, Platform } from 'ionic-angular';
import { Observable } from 'rxjs';
import { HelpersProvider } from '../../providers/helpers/helpers';
import * as constants from '../../util/constants';

@IonicPage()
@Component({
  selector: 'page-secure-access',
  templateUrl: 'secure-access.html',
})
export class SecureAccessPage {

  private timeData: number;
  tiempoConfigurado:number = 0;
  running:boolean = false;
  miliseconds:string = '00';
  minutos = 0;
  segundos = 0;
  idInt:any=null; 
  startStopBtnText:string = 'Activar acceso seguro';

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              private alertCtrl: AlertController,
              private ref: ChangeDetectorRef,
              public platform: Platform,
              public helper:HelpersProvider) {
  }
  
  //
  ionViewDidLoad() {
    console.log('ionViewDidLoad SecureAccessPage');
  }


  // Funcion del DOM que asigna
  // 
  setTime(time){
    console.log(this.helper.getPosition());
    // solo si no esta corriendo
    if(!this.running){
      this.minutos = time;
      this.segundos = 0;
      this.tiempoConfigurado = (60 * parseInt(time));
      console.log("configurado: ", this.tiempoConfigurado);
    }
  } 

  resetTime(){
    console.log("reset time");
    let _this = this;
    this.running = false;
    this.minutos = 0;
    this.segundos = 0;
    this.tiempoConfigurado = 0;
    try {
      clearInterval(_this.idInt);          
    } catch (error) {
      console.log(error);
    }
    this.miliseconds = '00';
  }
  
  //Modal que pide valor diferente a los preestablecidos
  setTimeOther(time:string){
    let alert = this.alertCtrl.create({
      title: 'Ingresar otro valor mayor',
      message: 'Ingrese el tiempo en minutos máximo 99 mins:',
      inputs: [
        {
          name: 'otherTime',
          type: 'number'
        }
      ],
      buttons: [
        {
          text: 'Cancelar'
        },
        {
          text: 'Aceptar',
          handler: data => {
            console.log(data)
            if (data.otherTime != "" && data.otherTime < "99" ) {
              this.setTime(data.otherTime);
            } else {
              return false;
            }
          }
        }
      ]
    });
    alert.present();
  }
  
  // Boton de detener
  startStopAction(){
    this.running = !this.running
    if(this.running){
      this.startStopBtnText = 'Detener acceso seguro'
    }else{
      this.startStopBtnText = 'Activar acceso seguro'
    }
  }

  miliseconsAnimation(){
    let _this = this;
    let count = 0;
    this.idInt = setInterval(function(){ 
      if(count == 10){
        count = 0;
      }
      //console.log("animation:"+count)
      _this.miliseconds = "0"+count; 
      _this.ref.detectChanges();
      count++;
    }, 100);
  }
  
  // Cuando la vista entre 
  ionViewWillEnter() {
    console.info("calling ionViewDidEnter");
    this.helper.isServiceRunning().then(data=>{
      if(data){
        this.onTimeNotification().subscribe((data: number) => {
          console.log(data);
          this.timeData = data;
          //this.miliseconsAnimation();
          this.ref.detectChanges();
          //Para cuando termine resetiar valores
          this.isFinishCount(data);
        }) 
      }
    }).catch(error=>{
      console.error(error);
    });
  } 


  isFinishCount(time){
    let _this = this;
    //Para cuando termine resetiar valores
    let sec:string = String(time / 1000);
    if (parseInt(sec) ===  1 ){
      setTimeout(function(){
        _this.resetTime();
      },900);
    }else{
      this.running = true;
    }
  } 

  //
  start() {
    //let _this = this;
    console.log(this.helper.getImei(), this.helper.getPosition() )
    // ingresar a la url desde el navegador para ver datos enviados.
    // https://ptsv2.com/t/count-down-background-test
    // https://ptsv2.com/t/count-down-background-test/post
    // 'https://ptsv2.com/t/count-down-background-test/post', //url a servidor
    let url = constants.URL_AWSHOST+"PanicButton"
    console.log("enviar a :", url);
    console.log(this.helper.getPosition());
    if(this.tiempoConfigurado > 0 && this.running == false){        
        console.log("config plugin");
        try {
          (<any>window).cordova.plugins.countDownBackground.setConfig({
            url: url, //url a servidor
            method: 'POST', //método POST o GET
            location: this.helper.getPosition(), //locacion del dispositivo
            imei: constants.imei, //valor numerico
            user_id: constants.Storage.getItem('user_id'), // id del usuario en el app
            time: this.tiempoConfigurado * 1000, //milisegundos
            type: 'AP' // este siempre será fijo.
          }, (data) => {
            console.log(data);
            this.onTimeNotification().subscribe((data: number) => {
              console.log("falta: ",data);
              //this.miliseconsAnimation();
              this.timeData = data;
              this.ref.detectChanges();
              //Para cuando termine resetiar valores
              this.isFinishCount(data);
            }) 
          }, (error) => {
            console.log(error);
          })          
        } catch (error) {
          console.log("no es movil!");
        }
    }
  }

  stop() {
    (<any>window).cordova.plugins.countDownBackground.stop((data) => {
      console.log(data);
      this.resetTime();  
    }, (error) => {
      this.resetTime(); 
      console.log(error);
    })
  }

  status() {
    let promise = new Promise((resolve,reject)=>{
      (<any>window).cordova.plugins.countDownBackground.getStatus((data) => {
        console.log(data);
        resolve(JSON.parse(data));
      }, (error) => {
        console.log(error);
        reject(error);
      })
    });
    return promise;
  }
  
  // metodo que valida si el servicio esta corriendo
  isServiceRunning() {
    let promise = new Promise((resolve, reject) => {
      (<any>window).cordova.plugins.countDownBackground.isServiceRunning((data) => {
        console.log(JSON.parse(data));
        resolve(JSON.parse(data));
      }, (error) => {
        this.running = false;
        console.log(error);
        reject(error);
      })
    });
    return promise;
  }
  
  // tiempo notificacion 
  onTimeNotification(){
    let observable = new Observable((observer) => {
      this.platform.ready().then(() => {
        (<any>window).cordova.plugins.countDownBackground.onTimeNotification(data => {
          observer.next(data);
        });
      })
    });
    return observable;
  }   

}
