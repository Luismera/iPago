import { Component, ViewChild, ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { GoogleMapsProvider } from '../../providers/google-maps/google-maps';
import * as Constants from '../../util/constants';
import { V } from '@angular/core/src/render3';

@IonicPage()
@Component({
  selector: 'page-set-address',
  templateUrl: 'set-address.html',
})
export class SetAddressPage {
  
  @ViewChild('map2') mapElement: ElementRef;
  map2: any;
  direction: any;
  map: any;
  searchQuery: string = '';
  suggestions: string[];
  historics: string[];
  inputSelect: string;
  searchInMap: boolean = false;

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public viewCtrl: ViewController,
              public googleMapsProv: GoogleMapsProvider) {

    //console.log("SetAddressPage ->");
    //console.log(this.navParams.get('direction'));
    //console.log(this.navParams.get('map'));
    //console.log(this.navParams.get('inputSelect'));
    this.direction = this.navParams.get('direction')
    this.map = this.navParams.get('map')
    this.inputSelect = this.navParams.get('inputSelect')
    this.initializeItems();

  }
  
  ionViewDidLoad() {
    console.log('ionViewDidLoad SetAddressPage');
    this.loadMap()
  }
  
  // inicializar items de listado
  initializeItems() {
    this.suggestions = [];
    let backupAddress = Constants.Storage.getItem('historic_address')
    this.historics = backupAddress ? JSON.parse(backupAddress) : []
    console.log(this.historics)
  }
  
  // obtener valores del buscador
  getItems(ev: any){
    // Restablecer sugerencias de nuevo
    this.initializeItems();

    // establece val al valor de la barra de búsqueda
    const val = ev.target.value;
    //console.log(val)

    // Si el valor es una cadena vacía, no filtre las sugerencias.
    if (val && val.trim() != '') {
      // obtenr las placas sugeridas por google map
      // desde el proveedor GoogleMapsProvider
      this.googleMapsProv.searchPlace({
        input: val,
        componentRestrictions: {country: 'co'},
        types: ['address']
      }).then((data:any)=>{
        //console.log(data)
        this.suggestions = data;
      }, (error) => console.error(error))
    }

  }

  // Seleccionar sugerencias
  selectSuggestion(suggestion:any){

    console.log(suggestion)
    // validar si esta seleccionado un item del historial
    if(suggestion.geometry){
      this.direction[this.inputSelect] = suggestion.geometry.location
      this.viewCtrl.dismiss(this.direction);  
    }else{
      // obtener el detalle de una placa 
      // con el api de google map 
      // desde el provedor GoogleMapsProvider
      this.googleMapsProv.detailPlace({
        map: this.map,
        place_id: suggestion.place_id
      }).then((data:any)=>{
        // insertar resultado en local storage y 
        // setiar objeto que sera enviado el mapa 
        // para que pinte la ruta
        console.log(data)
        this.historics.push(data)
        Constants.Storage.setItem('historic_address', JSON.stringify(this.historics))
        this.direction[this.inputSelect] = data.geometry.location
        this.viewCtrl.dismiss(this.direction);  
      }, (error) => console.error(error))
    }
     
  }
  
  // selecionar ubicacion actual
  currentLocation(){
    this.direction[this.inputSelect] = new google.maps.LatLng(Constants.locations.latitude, Constants.locations.longitude)
    this.viewCtrl.dismiss(this.direction); 
  }
  
  // buscar ubicacion desde el mapa
  selectMapLocation(){
    this.viewCtrl.dismiss(this.direction); 
  }

  // Volver sin hacer ningun cambio
  dismiss(){
    this.viewCtrl.dismiss();   
  }
  
  // cargar mapa
  loadMap(){
    let self = this

    // ubicacion por defecto
    let latLng = new google.maps.LatLng(Constants.locations.latitude, Constants.locations.longitude);
    
    // crear mapa
    this.map2 = this.googleMapsProv.create(this.mapElement.nativeElement, {
      center: latLng
    });

    // evento sobre el mapa
    this.map2.addListener('dragend', function() {
      let position = self.map2.getCenter()
      self.direction[self.inputSelect] = position
    });
 
  }
  
  // mostrar mapa oculto
  showMap(){
    this.searchInMap = true
  }

}
