import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { EventsProvider } from '../../providers/events/events';
import { EventsPage } from '../events/events';
import { EventFormPage } from '../event-form/event-form';


@IonicPage()
@Component({
  selector: 'page-event-categories',
  templateUrl: 'event-categories.html',
})
export class EventCategoriesPage {
  
  subcategories:any

  constructor(public loadingCtrl:LoadingController, 
              public navCtrl: NavController, 
              public navParams: NavParams,
              private eventsProv: EventsProvider) {
    
    let loading = this.loadingCtrl.create({
      spinner: 'dots',
      content: 'Cargando...'
    });  
    loading.present();
    
    console.log(this.navParams.get('id'))
    let idCategory = this.navParams.get('id')
    this.eventsProv.getSubcategories(idCategory).then((data)=>{
      console.log(data)
      this.subcategories = data;
      loading.dismiss();
    }, (error)=>{
      console.error(error)
    })

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EventCategoriesPage');
  }
  
  selectCategoryEvent(subcategory:any){
    this.navCtrl.push(EventFormPage, { subcategory: subcategory })
  }

  closeEvent(){
    this.navCtrl.push(EventsPage)
  }

}
