import { Component, ViewChild, ElementRef, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, ActionSheetController } from 'ionic-angular';
import { DestinationRoutePage } from '../destination-route/destination-route';
import { ListReportsEventsPage } from '../list-reports-events/list-reports-events';
import { EventCategoriesPage } from '../event-categories/event-categories';
import { GoogleMapsProvider } from '../../providers/google-maps/google-maps';
import { EventsProvider } from '../../providers/events/events';
import * as constants from '../../util/constants';
import moment from 'moment';
import { DetailReportEventPage } from '../detail-report-event/detail-report-event';
import lodash from 'lodash';
import { HelpersProvider } from '../../providers/helpers/helpers';


@IonicPage()
@Component({
  selector: 'page-events',
  templateUrl: 'events.html',
})
export class EventsPage {
  
  @ViewChild('map') mapElement:ElementRef
  map: any;
  icons:any = {
    1: {
      icon: 'assets/imgs/marker_trafico_small.png'
    },
    2: {
      icon: 'assets/imgs/marker_seguridad_small.png'
    }
  };
  novedades: any = [];

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public platform: Platform,
              public actionSheetCtrl: ActionSheetController,
              public googleMapsProv: GoogleMapsProvider,
              public eventsProv: EventsProvider,
              public zone: NgZone,
              public helperProv: HelpersProvider) {

    (window as any).ionicPageRef = { zone: zone, component: this };

    platform.ready().then(this.helperProv.configureBackgroundGeolocation.bind(this));

  }
  
  ngAfterViewInit(){
    this.loadMapTemp()
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EventsPage');
  }
  
  // mostrar hoja de acciones
  presentActionSheet() {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Seleccione una accion',
      buttons: [
        {
          text: 'Alerta de Transito',
          handler: () => {
            console.log('Transito clicked');
            this.navCtrl.push(EventCategoriesPage, { id: '1' })
          }
        },{
          text: 'Alerta de Seguridad',
          handler: () => {
            console.log('Seguridad clicked');
            this.navCtrl.push(EventCategoriesPage, { id: '2' })
          }
        },{
          text: 'Definir un destino',
          handler: () => {
            console.log('Definir un destino clicked');
            this.navCtrl.push(DestinationRoutePage, {
              route: {
                start_location: new google.maps.LatLng(constants.locations.latitude, constants.locations.longitude),
                start_address: "Tu ubicacion",
                end_location: new google.maps.LatLng(constants.locations.latitude, constants.locations.longitude),
                end_address: "",
                duration: {
                  text: ""
                },
                distance: {
                  text: ""
                }
              }
            })
          }
        }
      ]
    });
    actionSheet.present();
  }
  
  // ir al listado de novedades creadas por el mismo usuario
  listReports(){
    this.navCtrl.push(ListReportsEventsPage)
  }

  // cargar mapa
  loadMapTemp(){
    let self = this
    // ubicacion por defecto
    console.log("current position: ", constants.locations.latitude, constants.locations.longitude)
    let latLng = new google.maps.LatLng(constants.locations.latitude, constants.locations.longitude);
      
    // crear mapa
    this.map = this.googleMapsProv.create(this.mapElement.nativeElement, {
      center: latLng
    });
    
    // crear marcador
    this.googleMapsProv.addMarker({ 
      map: this.map, 
      position: latLng,
      icon: 'assets/imgs/marker_user_small.png'
    })
    
    //obtener novedades
    this.eventsProv.getNews().then((data:any)=>{
      self.novedades = data;
      let i;
      var infowindow = new google.maps.InfoWindow();
      for (i = 0; i < data.length; i++) {
        //crear position
        let position = new google.maps.LatLng(Number(data[i].latitud), Number(data[i].longitud))
        //crear marker
        let marker = this.googleMapsProv.addMarker({ 
          map: self.map, 
          position: position, 
          icon: self.icons[data[i].type].icon,
          title: data[i].title
        })  
        var hora = moment(data[i].created_at).format('LT');
        //evento de click en los marcadores
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
          return function() {
            infowindow.setContent(`<div class="info-popup-map type_${data[i].type}">
                                      <div class="date">${hora}</div>
                                      <div class="head-popup-map">
                                        <img src="${data[i].category.icon}" width="15px" class="icono-popup-map">
                                        <div class="title">${data[i].title}</div>
                                        <div class="category">${data[i].category.name}</div>
                                      </div>
                                      <div class="description">${data[i].description}</div>
                                      <button onclick="window.ionicPageRef.zone.run(function () { window.ionicPageRef.component.viewEvent(${data[i].id}) })">Ver detalles</button>
                                   </div>`);
            infowindow.open(self.map, marker)
          }
        }) (marker, i));
      }
    }, (error)=>{
      console.error(error)
    })

  }
  
  // ir al detalle de una novedad
  viewEvent( idEvent:any ) {
    let report = lodash.find(this.novedades, { id: String(idEvent) } );
    console.log(report)  
    this.navCtrl.push(DetailReportEventPage, { report: report })
  }
  
}
