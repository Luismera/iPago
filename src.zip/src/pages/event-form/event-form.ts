import { Component, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { ModalController, IonicPage, NavController, NavParams, Platform } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EventsPage } from '../events/events';
import { GoogleMapsProvider } from '../../providers/google-maps/google-maps';
import { HelpersProvider } from '../../providers/helpers/helpers';
import { FormsProvider } from '../../providers/forms/forms';
import { EventsProvider } from '../../providers/events/events';
import * as Constants from '../../util/constants';
//import { Socket } from 'ng-socket-io';

@IonicPage()
@Component({
  selector: 'page-event-form',
  templateUrl: 'event-form.html',
})
export class EventFormPage {
  
  @ViewChild('map') mapElement: ElementRef;
  map: any;
  myForm: FormGroup;
  formErrors = {
    title: [''],
    description: [''],
    latitud: [''],
    longitud: [''],
    id_category: ['']
  }
  showMessages:boolean = false
  infoCategory:any

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public platform: Platform,
              public formBuilder: FormBuilder,
              public modalCtrl: ModalController,
              public googleMapsProv: GoogleMapsProvider,
              public helpersProv: HelpersProvider,
              private ref: ChangeDetectorRef,
              public FormService: FormsProvider,
              //private socket: Socket
              private eventsProv: EventsProvider) {

    this.infoCategory = this.navParams.get('subcategory')
    this.myForm = this.createMyForm();
    //setiar valor de categoria
    this.myForm.patchValue({
      id_category: this.infoCategory.id_category
    })

    // Sucribirse a cambios 
    // Data es un array de los valores del formulario this.myForm
    this.myForm.valueChanges.subscribe((data) => {
      this.formErrors = this.FormService.validateForm(this.myForm, this.formErrors, true)
      //console.log("errores :", this.formErrors);
      this.ref.detectChanges();
    });

    //this.socket.connect();

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EventFormPage');
    this.loadMap();
  }
 
  loadMap(){
    let self = this

    // setiar valores de logitud y latitud
    this.myForm.patchValue({
      latitud: Constants.locations.latitude,
      longitud: Constants.locations.longitude
    })
    
    // ubicacion por defecto
    let latLng = new google.maps.LatLng(Constants.locations.latitude, Constants.locations.longitude);
    
    // crear mapa
    this.map = this.googleMapsProv.create(this.mapElement.nativeElement, {
      center: latLng
    });

    // evento sobre el mapa
    this.map.addListener('dragend', function() {
      let position = self.map.getCenter()
      // setiar valores de logitud y latitud si cambia de posicion
      self.myForm.patchValue({
        latitud: position.lat(),
        longitud: position.lng()
      })
      console.log(position.lat(), position.lng())
    });
 
  }

  saveData(){
    console.log(this.myForm.value);
    this.FormService.markFormGroupTouched( this.myForm );
    if(this.myForm.valid){
      //this.socket.emit('add-location', this.myForm.value);
      this.eventsProv.createNews(this.myForm.value).then((data:any)=>{
        this.showMessages = true;
      }, (error)=>{
        this.showMessages = false;
        alert(error)
      })
    }else{
      this.formErrors = this.FormService.validateForm(this.myForm, this.formErrors, false)
      this.ref.detectChanges();
    }
  }
  
  private createMyForm(){
    return this.formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      latitud: ['', Validators.required],
      longitud: ['', Validators.required],
      id_category: ['', Validators.required]
    });
  }
  
  closeEvent(){
    this.showMessages = false
    this.navCtrl.push(EventsPage)
  }

}