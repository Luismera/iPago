import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Platform, AlertController } from 'ionic-angular';
import { AuthProvider } from '../../providers/auth/auth';
import { HelpersProvider } from '../../providers/helpers/helpers';
import { HomePage } from '../home/home';
import { ForgotPage } from '../forgot/forgot';
import { Device } from '@ionic-native/device';
import { AppVersion } from '@ionic-native/app-version';
import * as constants from '../../util/constants';
import { FcmProvider } from '../../providers/fcm/fcm';
import { EventsPage } from '../events/events';
import { SystemListPage } from '../system-list/system-list';
import { tap } from 'rxjs/operators';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  
  username: string = '';
  password: string = '';
  loading = null;
  
  constructor(public loadingCtrl:LoadingController, 
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public loginService:AuthProvider, 
              public helper:HelpersProvider,
              private device: Device,
              public fcm: FcmProvider,
              public alertCtrl: AlertController, 
              public platform: Platform,
              private appVersion: AppVersion) {
  
    this.loading = this.loadingCtrl.create({
      spinner: 'dots',
      content: 'Cargando cuentas...'
    });    
  }
  
  login(){
    //validar
    if(this.username == ''  || this.password == ''){
      console.log("entro")
      this.helper.showAlert("Debe ingresar un usuario y contraseña","Aviso");
      return false
    }  
    this.loading.present();
    //console.log(this.username, this.password);
    let credentials = {
      username: this.username,
      password: this.password,
      deviceInfo:{
        deviceModel: this.device.model,
        deviceManufacturer: this.device.manufacturer,
        devicePlatform: this.device.platform,
        deviceOSVersion: this.device.version,
        deviceUUID : this.device.uuid,
        deviceisVirtual: this.device.isVirtual,
        appVersion: this.appVersion.getVersionNumber(),
        imei: constants.imei,
        connectionType: this.helper.getConnectionType()
      }
    }

    console.log("Credenciales: ",credentials)
    
    this.loginService.login(this.username, this.password)
                      .then((data)=>{
                          console.log(data);
                          this.initPushNotification();
                          this.navCtrl.push(HomePage,{},{animate: true, direction: 'forward'});
                          this.loading.dismiss();
                      }).catch((error) =>{
                        this.loading.dismiss();
                        this.helper.showAlert(error,"Aviso"); 
                      })
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  viewForgot(){
    this.navCtrl.push(ForgotPage);
  }

  initPushNotification(){
    if(this.platform.is('cordova')){
      // obtener el token de provedor FCM
      this.fcm.getToken()

      // Escuchar los mensajes entrantes
      this.fcm.listenToNotifications().pipe(
        tap((msg:any) => {
          // Mostrar alerta
          console.log(msg)
          let alert = this.alertCtrl.create({
            title: msg.title,
            message: msg.description,
            buttons: [
              {
                text: 'Cancelar',
                role: 'cancel',
                handler: () => {
                  console.log('Cancel clicked');
                }
              },
              {
                text: 'Aceptar',
                handler: () => {
                  switch(msg.page) {
                    case "EventsPage":
                      this.navCtrl.push(EventsPage);
                      break;
                    case "SystemListPage":
                      this.navCtrl.push(SystemListPage);
                      break;
                    default:
                      this.navCtrl.push(EventsPage);
                  }
                }
              }
            ]
          });
          alert.present();
        })
      ).subscribe()

      // Escuchar los cambios del token
      this.fcm.listenTokenToRefresh().subscribe((token: string) => {
        console.log(`Got a new token ${token}`)
        let platform = this.platform.is('android') ? 'android' : 'ios';
        this.fcm.saveTokenToFirestore(token, platform)
      })

    }
  }

}
