import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailReportEventPage } from './detail-report-event';

@NgModule({
  declarations: [
    DetailReportEventPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailReportEventPage),
  ],
})
export class DetailReportEventPageModule {}
