import { Component, ElementRef, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform } from 'ionic-angular';
import { GoogleMaps, GoogleMap, GoogleMapOptions, GoogleMapsEvent } from '@ionic-native/google-maps';
import { GoogleMapsProvider } from '../../providers/google-maps/google-maps';
import { EventsProvider } from '../../providers/events/events';


@IonicPage()
@Component({
  selector: 'page-detail-report-event',
  templateUrl: 'detail-report-event.html',
})
export class DetailReportEventPage {
  
  report:any = {}
  @ViewChild('map') mapElement:ElementRef
  //map: GoogleMap;
  map: any;

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public platform: Platform,
              public eventsProv: EventsProvider,
              public googleMapsProv: GoogleMapsProvider) {

    console.log(this.navParams.get('report'))
    this.report = this.navParams.get('report')
  
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DetailReportEventPage');
  }

  ngAfterViewInit(){
    if(this.platform.is('cordova')){
      this.loadMapTemp()
      //this.loadMap();
    }else{
      this.loadMapTemp()
    }
  }

  loadMap(){

    let mapOptions: GoogleMapOptions = {
      camera: {
        target: {
          lat: Number(this.report.latitud), // default location
          lng: Number(this.report.longitud) // default location
        },
        zoom: 17
      }
    };
    
    let element = this.mapElement.nativeElement
    this.map = GoogleMaps.create(element, mapOptions);

    // Wait the MAP_READY before using any methods.
    this.map.one(GoogleMapsEvent.MAP_READY)
    .then(() => {
      // Now you can use all methods safely.
      //this.getPosition();
      this.map.addMarker({
        title: this.report.title,
        animation: 'DROP',
        position: {
          lat: Number(this.report.latitud), // default location
          lng: Number(this.report.longitud) // default location
        }
      });
    })
    .catch(error =>{
      console.log(error);
    });

  }

  loadMapTemp(){
    // ubicacion por defecto
    let latLng = new google.maps.LatLng(Number(this.report.latitud), Number(this.report.longitud));
          
    // crear mapa
    this.map = this.googleMapsProv.create(this.mapElement.nativeElement, {
      center: latLng
    });
    
    let marker = this.googleMapsProv.addMarker({
      map: this.map,
      position: latLng
    })
  }

}
