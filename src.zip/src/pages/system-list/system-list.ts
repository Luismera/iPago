import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { SystemProvider } from '../../providers/system/system';
import { HelpersProvider } from '../../providers/helpers/helpers';
import { SystemPage } from '../system/system';
/**
 * Generated class for the SystemListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-system-list',
  templateUrl: 'system-list.html',
})
export class SystemListPage {
  actividades:any = [];
  loading:any = null; 
  
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public helper:HelpersProvider, 
              public systemService:SystemProvider,
              public loadingCtrl: LoadingController) {
    this.loading = this.loadingCtrl.create({
      spinner: 'dots',
      content: 'Cargando cuentas...'
    });
  }
  
  // metodo que trae las cuentas asociadas al usuario
  getActivities(){
    this.loading.present();
    this.systemService.getUserActivities()
                    .then((data)=>{
                        this.loading.dismiss(); 
                        console.log(data);
                        this.actividades = data;
                    }).catch((error) =>{
                        this.loading.dismiss();
                        this.helper.showAlert(error,"Aviso"); 
                    })

  }

  showActivity(activity){
    this.navCtrl.push(SystemPage, {activity:activity} );
    //console.log(activity);
  }  

  ionViewDidLoad() {
    this.actividades = [];
    this.getActivities(); 
    console.log('ionViewDidLoad SystemListPage');
  }

}
