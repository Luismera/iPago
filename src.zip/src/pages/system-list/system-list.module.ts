import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SystemListPage } from './system-list';

@NgModule({
  declarations: [
    SystemListPage,
  ],
  imports: [
    IonicPageModule.forChild(SystemListPage),
  ],
})
export class SystemListPageModule {}
