import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { AuthProvider } from '../../providers/auth/auth';

/**
 * Generated class for the ForgotPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-forgot',
  templateUrl: 'forgot.html',
})
export class ForgotPage {
  
  useremail:string = '';
  message:string = '';

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public authProv: AuthProvider,
              private alertCtrl: AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ForgotPage');
  }

  forgot(){
    this.authProv.forgot(this.useremail).then((data)=>{
      console.log(data);
      this.message = String(data);
      this.useremail = '';
    }, (error)=>{
      console.error(error)
      this.message = '';
      let alert = this.alertCtrl.create({
        title: 'Aviso',
        message: error,
        buttons: ['Aceptar']
      });
      alert.present();
    })
  }

  backLogin(){
    this.message = '';
    this.navCtrl.push(LoginPage)
  }

}
