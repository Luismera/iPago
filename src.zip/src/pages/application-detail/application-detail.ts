import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ApplicationsProvider } from '../../providers/applications/applications';
import { HelpersProvider } from '../../providers/helpers/helpers';

@IonicPage()
@Component({
  selector: 'page-application-detail',
  templateUrl: 'application-detail.html',
})
export class ApplicationDetailPage {
  
  application:any = {}
  introDisable:boolean;
  labelButton:string = "Abrir";

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public applicationsProv: ApplicationsProvider,
              public helper: HelpersProvider) {

    console.log(this.navParams.get('app'))
    this.application = this.navParams.get('app')
    if(this.application.type == 'application'){
      this.helper.appIsInstalled(this.application.path, (appIsInstall)=>{
        if(appIsInstall){
          this.labelButton = 'Abrir aplicación'
        }else{
          this.labelButton = 'Instalar aplicación'
        }
      })
    }else{
      this.labelButton = 'Abrir página'
    }
      
  }
  
  ionViewDidLoad() {
    console.log('ionViewDidLoad ApplicationDetailPage');
  }

  makeIntroDisable(app:string){
    app['status'] = true
    this.applicationsProv.disableIntro(app)
  }

  openApplication(app:any){
    let self = this
    if (app.type === 'link') {
      self.helper.open(app.path);
    } else {
      this.helper.appIsInstalled(app.path, function(appIsInstall) {
        if (appIsInstall) {
          self.helper.appLaunch(app.path, function() {});
        } else {
          self.helper.open('https://play.google.com/store/apps/details?id=' + app.path);
        }
      });
    }
  }

}
