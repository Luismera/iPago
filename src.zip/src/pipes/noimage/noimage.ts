import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'noimage'
})
export class NoimagePipe implements PipeTransform {

  transform(image: string): string {
    if (!image){
      return 'assets/imgs/sin-imagen.png'
    }

    if (image != null){
      return image
    } else {
      return 'assets/imgs/sin-imagen.png'
    }
  }

}