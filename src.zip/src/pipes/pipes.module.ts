import { NgModule } from '@angular/core';
import { DomseguroPipe } from './domseguro/domseguro';
import { NoimagePipe } from './noimage/noimage';
@NgModule({
	declarations: [DomseguroPipe,
    NoimagePipe],
	imports: [],
	exports: [DomseguroPipe,
    NoimagePipe]
})
export class PipesModule {}
