import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, AlertController,App } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { EventsPage } from '../pages/events/events';
import { SystemListPage } from '../pages/system-list/system-list';
import { LoginPage } from '../pages/login/login';
import { AuthProvider } from '../providers/auth/auth';
import { HelpersProvider } from '../providers/helpers/helpers';
import { Geolocation } from '@ionic-native/geolocation';
import * as constants from '../util/constants';
import { SecureAccessPage } from '../pages/secure-access/secure-access';

import { FcmProvider } from '../providers/fcm/fcm';

import { ToastController } from 'ionic-angular';
//import { Subject } from 'rxjs/Subject';
import { tap } from 'rxjs/operators';
//import { SystemPage } from '../pages/system/system';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any;
  pages: Array<{title: string, component: any, icon: string}>;

  constructor(public platform: Platform, 
              public statusBar: StatusBar, 
              public splashScreen: SplashScreen, 
              public login:AuthProvider, 
              public alertCtrl: AlertController, 
              public helper:HelpersProvider, 
              public geolocation:Geolocation, 
              public app: App,
              public fcm: FcmProvider,
              public toastCtrl: ToastController) {

    this.initializeApp();

    //TODO: Cambiar esto
    this.helper.checkGPS(function(status){
      console.log("status GPS: ", status)
    });

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Inicio', component: HomePage, icon: 'home' },
      { title: 'Reportes Novedades', component: EventsPage, icon: 'beenhere' },
      { title: 'Actividad Sistema', component: SystemListPage, icon: 'person-pin' }
      //{ title: 'Cerrar sesión', component: LoginPage, icon: 'exit-to-app'}
    ];
    
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      
      //this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.statusBar.styleLightContent()
      
      // AUTENTICACION 
      if (this.login.isUserAuthenticated()){
        // iniciar notificaciones push
        this.initPushNotification()
        //VALICION SI ESTA CORRIENDO SERVICIO
        this.helper.isServiceRunning().then(data=>{
          if(data){
            this.rootPage = SecureAccessPage;             
          }else{
            this.rootPage = HomePage; 
          }
        }).catch(error=>{
          console.error(error);
        });
      }else{
        this.rootPage = LoginPage;
      }
      
      // IMEI
      if (this.platform.is('android') || this.platform.is('mobileweb')) {
        this.helper.getImei()
      }

      //REGISTER BACK BUTTON
      // Evita que desde el home se pueda volver a atras 
      // 
      this.platform.registerBackButtonAction(() => {
        console.log('backbutton pressed');
        let nav = this.app.getActiveNavs()[0];
        let activeView = nav.getActive();
        console.log(activeView.name); 
        if(activeView.name === "HomePage") {
          // 
          if (nav.canGoBack()){ //Can we go back?
            console.log("puedo volver:"+nav.canGoBack())
            nav.pop();
          }else{
            const alert = this.alertCtrl.create({
              title: 'Salir',
              message: '¿Desea salir de la aplicación?',
              buttons: [{
                  text: 'Cancel',
                  role: 'cancel',
                  handler: () => {
                      console.log('Application exit prevented!');
                  }
              },{
                  text: 'Salir',
                  handler: () => {
                      this.platform.exitApp(); // Close this application
                  }
              }]
          });
          alert.present();
            
          }
        }else{
          this.platform.runBackButtonAction();
        }
        
      },1); 

      //WATCH POSITION
      let optionsWatch = {
        frequency: 3000,
        enableHighAccuracy: true
      };
      this.geolocation.watchPosition(optionsWatch)
                      .subscribe(position => {
                        //console.log("WATCH POSITION: ",position.coords)
                        constants.setLocation(position.coords); 
                      });

    });
  }

  logout(){
    let alert = this.alertCtrl.create({
      title: 'Cerrar sesión ',
      message: '¿Desea cerrar sesión?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Aceptar',
          handler: () => {
            this.login.logout();
            this.nav.setRoot(LoginPage);
            //console.log('Aceptar clicked');
          }
        }
      ]
    });
    alert.present();
  } 

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    /*
    if(page.title == 'Reportes Novedades'){ 
      this.helper.showAlert("Esta funcionalidad estará disponible en la próxima versión","Aviso");
      return false
    } 
    */ 
    if(page.title == 'Inicio'){ 
      this.nav.setRoot(page.component); 
      return false
    }  
    this.nav.push(page.component); 
  }  

  initPushNotification(){
    if(this.platform.is('cordova')){
      // obtener el token de provedor FCM
      this.fcm.getToken()

      // Escuchar los mensajes entrantes
      this.fcm.listenToNotifications().pipe(
        tap((msg:any) => {
          // Mostrar alerta
          console.log(msg)
          let alert = this.alertCtrl.create({
            title: msg.title,
            message: msg.description,
            buttons: [
              {
                text: 'Cancelar',
                role: 'cancel',
                handler: () => {
                  console.log('Cancel clicked');
                }
              },
              {
                text: 'Aceptar',
                handler: () => {
                  switch(msg.page) {
                    case "EventsPage":
                      this.nav.push(EventsPage);
                      break;
                    case "SystemListPage":
                      this.nav.push(SystemListPage);
                      break;
                    default:
                      this.nav.push(EventsPage);
                  }
                }
              }
            ]
          });
          alert.present();
        })
      ).subscribe()

      // Escuchar los cambios del token
      this.fcm.listenTokenToRefresh().subscribe((token: string) => {
        console.log(`Got a new token ${token}`)
        let platform = this.platform.is('android') ? 'android' : 'ios';
        this.fcm.saveTokenToFirestore(token, platform)
      })

    }
  }

  
}
