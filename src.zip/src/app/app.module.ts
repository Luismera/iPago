import { BrowserModule, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { ErrorHandler, NgModule, LOCALE_ID } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpClientModule } from '@angular/common/http';

import { registerLocaleData } from '@angular/common';
import localeEsCo from '@angular/common/locales/es-CO';


// COMPONENTS
import { MyApp } from './app.component';

// PAGES
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { ApplicationDetailPage } from '../pages/application-detail/application-detail';
import { EventsPage } from '../pages/events/events';
import { ForgotPage } from '../pages/forgot/forgot';
import { SystemPage } from '../pages/system/system';
import { SystemListPage } from '../pages/system-list/system-list';
import { SecureAccessPage } from '../pages/secure-access/secure-access';
import { EventCategoriesPage } from '../pages/event-categories/event-categories';
import { EventFormPage } from '../pages/event-form/event-form';
import { DestinationRoutePage } from '../pages/destination-route/destination-route';
import { ListReportsEventsPage } from '../pages/list-reports-events/list-reports-events';
import { DetailReportEventPage } from '../pages/detail-report-event/detail-report-event';

// PROVIDERS
import { ApplicationsProvider } from '../providers/applications/applications';
import { AuthProvider } from '../providers/auth/auth';
import { SystemProvider } from '../providers/system/system';
import { SecurityProvider } from '../providers/security/security';
import { HelpersProvider } from '../providers/helpers/helpers';
import { EventsProvider } from '../providers/events/events';
import { FcmProvider } from '../providers/fcm/fcm';
import { GoogleMapsProvider } from '../providers/google-maps/google-maps';
import { FormsProvider } from '../providers/forms/forms';

// PIPES
import { DomseguroPipe } from '../pipes/domseguro/domseguro';
import { NoimagePipe } from '../pipes/noimage/noimage';

// NATIVE 
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Geolocation } from '@ionic-native/geolocation';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Dialogs } from '@ionic-native/dialogs';
import { IonicGestureConfig } from "../gestures/ionic-gesture-config";
import { Device } from '@ionic-native/device';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { CallNumber } from '@ionic-native/call-number';
import { GoogleMaps } from '@ionic-native/google-maps';
import { Firebase } from '@ionic-native/firebase';
import { AppVersion } from '@ionic-native/app-version';
import { Network } from '@ionic-native/network';

import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { SetAddressPage } from '../pages/set-address/set-address';

//import { SocketIoModule, SocketIoConfig } from 'ng-socket-io';
//const config: SocketIoConfig = { url: 'http://realt.sti-atlas.com.co:3001', options: {} };

  
registerLocaleData(localeEsCo);


const firebase = {
  apiKey: 'AIzaSyCP_lSNf6Q4iqTPrOTDfQ6hYDQPsYGGPdk',
  projectId: 'vivoseguropro',
  messagingSenderId: '734192640887'
}

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    ForgotPage,
    ApplicationDetailPage,
    EventsPage,
    SystemPage,
    SystemListPage,
    SecureAccessPage,
    DomseguroPipe,
    NoimagePipe,
    EventCategoriesPage,
    EventFormPage,
    DestinationRoutePage,
    ListReportsEventsPage,
    DetailReportEventPage,
    SetAddressPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp, {
      platforms: {
        ios: {
          backButtonText: '',
          backButtonIcon: 'ios-arrow-round-back'
        }
      }
    }),
    HttpClientModule,
    AngularFireModule.initializeApp(firebase), 
    AngularFirestoreModule
    //SocketIoModule.forRoot(config)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    ForgotPage,
    ApplicationDetailPage,
    EventsPage,
    SystemPage,
    SystemListPage,
    SecureAccessPage,
    EventCategoriesPage,
    EventFormPage,
    DestinationRoutePage,
    ListReportsEventsPage,
    DetailReportEventPage,
    SetAddressPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    GoogleMaps,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    {provide: HAMMER_GESTURE_CONFIG, useClass: IonicGestureConfig},
    ApplicationsProvider,
    AuthProvider,
    SecurityProvider,
    SystemProvider,
    HelpersProvider,
    Geolocation,
    Diagnostic,
    Dialogs,
    Device,
    CallNumber,
    InAppBrowser,
    {provide: LOCALE_ID, useValue: "es-CO"},
    EventsProvider,
    GoogleMapsProvider,
    FormsProvider,
    Firebase,
    FcmProvider,
    AppVersion,
    Network
  ]
})
export class AppModule {}
