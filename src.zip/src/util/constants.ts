export const notAuthenticated = 'auth-not-authenticated';
export const URL_HOST = 'http://app.indata.com.co/backend.php/api/mobile/';
export const URL_AWSHOST = 'http://vivoseguro.sti-atlas.com.co/index.php/api/mobile/';
export let imei= null;
export let Storage = window.localStorage;
export let locations= null;
export let watchId = null;

//set variables 
export let setLocation = function(valor){
    locations = valor;
}
export let setImei = function(valor){
    imei = valor;
}