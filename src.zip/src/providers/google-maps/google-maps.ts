import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Geolocation } from '@ionic-native/geolocation';

@Injectable()
export class GoogleMapsProvider {
  
  mapOptions:any = {
    center: new google.maps.LatLng(3.43444463, -76.52564415),
    zoom: 15,
    mapTypeId: google.maps.MapTypeId.ROADMAP,
    disableDefaultUI: true,
    styles: [
        {
            "featureType": "administrative.country",
            "elementType": "geometry",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.country",
            "elementType": "labels",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.province",
            "elementType": "geometry",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.province",
            "elementType": "labels",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.locality",
            "elementType": "geometry",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.locality",
            "elementType": "labels",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.neighborhood",
            "elementType": "geometry",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.neighborhood",
            "elementType": "labels",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.land_parcel",
            "elementType": "geometry",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "administrative.land_parcel",
            "elementType": "labels",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "poi",
            "elementType": "all",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "road",
            "elementType": "all",
            "stylers": [
                {
                    "visibility": "on"
                }
            ]
        }
    ]
  }

  markerOptions:any = {
    map: null,
    position: new google.maps.LatLng(3.43444463, -76.52564415)
  }

  directionsService = new google.maps.DirectionsService();
  directionsDisplay = new google.maps.DirectionsRenderer();
  autocompleteService = new google.maps.places.AutocompleteService();


  constructor(public http: HttpClient,
              public geolocation: Geolocation) {
    console.log('Hello GoogleMapsProvider Provider');
  }
  
  /**
   * Crea una nueva instancia de google map
   * @param element {string | HTMLElement} ID de elemento o referencia para adjuntar el mapa a
   * @param options {google} [options] Opciones
   * @return {google}
   */
  create(element: any, options?: google.maps.MapOptions):google.maps.Map{
    let opts = Object.assign({}, this.mapOptions, options);
    return new google.maps.Map(element, opts)
  }

  /**
   * Crea una nueva marcador de google map
   * @param options {google} [options] Opciones
   * @return {google}
   */
  addMarker(options){
    let opts = Object.assign({}, this.markerOptions, options);
    return new google.maps.Marker(opts)
  }
  
  /**
   * Obtener posicion actual
   * @return {cordenadas}
   */
  getPosition(){
    return new Promise((resolve, reject) => {
      this.geolocation.getCurrentPosition().then((rest)=>{
        resolve(rest)
      }).catch((error)=>{
        reject(error)
      })
    }) 
  }
  
  /**
   * Obtener ruta y pintarla ene l mapa
   * @param options {google} [options] Opciones
   * @return {objeto}
   */
  directions(options){
    return new Promise((resolve, reject) => {
        let polyline = {
            strokeColor: '#01315C',
            strokeOpacity: 1,
            strokeWeight: 3
        }
        this.directionsDisplay.setOptions({
            suppressMarkers: true,
            polylineOptions: polyline
        });
        this.directionsDisplay.setMap(options.map);
        this.directionsService.route(options.request, (result:any, status:any) => {
            if (status == 'OK') {
                this.directionsDisplay.setDirections(result);
                resolve(result)
            }else{
                reject("No se puedo obtener una ruta por: "+status)
            }
        });
    }) 
  }
  
  /**
   * busca sugerencias de mapa
   * @param options {google} [options] Opciones
   * @return {objeto}
   */
  searchPlace(options:any){
    return new Promise((resolve, reject) => {
      this.autocompleteService.getPlacePredictions(options, (result, status) => {
        if(status == google.maps.places.PlacesServiceStatus.OK){
          resolve(result)
        }else{
          reject(status)
        }
      })
    })     
  }
  
  /**
   * obtiene detalle de una sugerencias
   * @param options {google} [options] Opciones
   * @return {objeto}
   */
  detailPlace(options:any){
    return new Promise((resolve, reject) => {
      let placesService = new google.maps.places.PlacesService(options.map)
      placesService.getDetails({placeId: options.place_id}, (details) => {
        resolve(details)
      })
    })     
  }

}
