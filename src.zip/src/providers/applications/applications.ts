import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import * as Constants from '../../util/constants';
import lodash from 'lodash';

@Injectable()
export class ApplicationsProvider {

  constructor(public http: HttpClient) {
    console.log('Hello ApplicationsProvider Provider');
  }
  
  /*
   * Definir variables
   */
  applicationsStorage:any[] = [];
  applications:any[] = [];

  /*
   * @name getApplications
   * @desc obtener todas las aplicaciones
   * @returns retorn un arrray con las aplicaciones
   */
  getApplications() {
    return this.http.get(`${Constants.URL_AWSHOST}Apps?user_id=${Constants.Storage.getItem('user_id')}`).pipe( map( (data:any) => data.response ) )
  };

  /*
   * @name disableIntro
   * @desc oculta el intro aplicacion
   * @param {data} info completa de la aplicacion
   */
  disableIntro(data) {
    this.applicationsStorage = window.localStorage.getItem('applications') === null ? [] : JSON.parse(window.localStorage.getItem('applications'));
    this.applicationsStorage.push(data);
    window.localStorage.setItem('applications', JSON.stringify(this.applicationsStorage));
  };

  /*
   * @name hasDisableIntro
   * @desc validar de la aplicacion tiene el intro oculto
   * @param {id} id de la aplicacion
   * @returns retorna true o false si la aplicacion tiene el intro desactivado
   */
  hasDisableIntro(idx:string) {
    let itemApplicationsStorage;
    this.applicationsStorage = JSON.parse(window.localStorage.getItem('applications'));
    
    itemApplicationsStorage = lodash.find(this.applicationsStorage, { id: idx } );
    console.log(itemApplicationsStorage)  

    if (typeof itemApplicationsStorage != 'undefined') {
      return true;
    } else {
      return false;
    }
  };



}
