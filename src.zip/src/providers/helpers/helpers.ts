import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Geolocation } from '@ionic-native/geolocation';
import * as constants from '../../util/constants';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Dialogs } from '@ionic-native/dialogs';
import { Platform } from 'ionic-angular';
import { Network } from '@ionic-native/network';
import BackgroundGeolocation, {
  State,
  Config,
  Location,
  LocationError,
  Geofence,
  HttpEvent,
  MotionActivityEvent,
  ProviderChangeEvent,
  MotionChangeEvent,
  GeofenceEvent,
  GeofencesChangeEvent,
  HeartbeatEvent,
  ConnectivityChangeEvent
} from "cordova-background-geolocation-lt";


@Injectable()
export class HelpersProvider {

  constructor(public http: HttpClient, 
              public geolocation:Geolocation, 
              private diagnostic: Diagnostic, 
              private dialogs: Dialogs,
              public platform: Platform,
              private network: Network) {

    console.log('Hello HelpersProvider Provider');
    
  }

  local_id() {
    return '_' + Math.random().toString(36).substr(2, 9);
  };
  
  showConfirm(message, title, options) {
    this.dialogs.confirm(message, title, options)
                .then((data) => {
                  console.log('Dialog dismissed', data);
                }).catch(e => {
                  console.error('Error displaying dialog', e);
                  confirm(message)
                });
  };
  
  showAlert(message, title) {
    this.dialogs.alert(message, title, "Aceptar")
                .then(() => {
                  console.log('Dialog dismissed')
                }).catch(e => {
                  console.error('Error displaying dialog', e)
                  alert(message)
                });
  };
  
  validResponse(res) {
    return (res.success != null) && res.success === 1;
  };
  
  appIsInstalled(path, callback) {
    let confg = {}
    if(this.platform.is('android')){
      confg = { packageName: path }
    }
    if(this.platform.is('ios')){
      confg = {uri:'fb://'+path}
    }
    if (this.platform.is('cordova')) {
      (<any>window).plugins.launcher.canLaunch(confg, function(fail) {
        console.info('la aplicacion '+path+' esta ', fail);
        return callback(true);
      }, function(success) {
        console.info('la aplicacion '+path+' esta ', success);
        return callback(false);
      });
    }else{
      return callback(false);
    }
  };
  
  appLaunch(path, callback) {
    let confg = {}
    if(this.platform.is('android')){
      confg = { packageName: path }
    }
    if(this.platform.is('ios')){
      confg = {uri:'fb://'+path}
    }
    if (this.platform.is('cordova')) {
      (<any>window).plugins.launcher.launch(confg, function(data) {
        console.info("La aplicacion abrio con exito!");
        return callback(true);
      }, function(errMsg) {
        console.error("La aplicacion no puedo abrir por el sigueinte error: " + errMsg);
        return callback(false);
      });
    }else{
      (<any>window).open('https://play.google.com/store/apps/details?id=' + path, '_system');
    }
  };

  //Retorna string de la posicion en formato : lat,long
  getPosition(){
    let position ='';
    if(constants.locations && typeof constants.locations == 'object')
      position = `${constants.locations.latitude}, ${constants.locations.longitude}`;     
    return position;
  }

  //Actualiza la variable que hay en coords a la variable global
  getUserPosition(){
    this.geolocation.getCurrentPosition().then((resp) => {
      constants.setLocation(resp.coords);
    }).catch((error) => {
       console.log('Error getting location', error);
    });
  }

  //Valida si tiene localizacion(GPS) de android encendido
  //y con diagnostic abre configuracion de localizacion(GPS) de android si no esta activo
  checkGPS(cb){
    const self = this
    try {
      this.diagnostic.isLocationEnabled().then((enabled)=>{
        if(enabled){
           setTimeout(function(){
              self.getUserPosition();
           },1000);
           cb(true);
        }else{
          this.diagnostic.switchToLocationSettings();
          cb(false);
        }
      }).catch(error =>{
        console.error("Error diagnosing the GPS: "+error)
      })

    } catch (error) {
      //es web y no tiene 
      console.log("web")
    }
  } 

  getImei(){
    if (this.platform.is('cordova')) {
      (<any>window).cordova.plugins.IMEI((err, imei)=> {
        console.log('imei: ', imei)
        constants.setImei(imei)
      })
    }else{
      console.log('imei pruebas: 358978063142876')
      constants.setImei('358978063142876')
    }
  }

  open(url){
    if (this.platform.is('cordova')) {
      (<any>window).cordova.InAppBrowser.open(url, '_system', 'location=yes');
    }else{
      (<any>window).open(url, '_system')
    }
  }

  isServiceRunning() {
    let promise = new Promise((resolve, reject) => {
      if (this.platform.is('cordova')) {
        (<any>window).cordova.plugins.countDownBackground.isServiceRunning((data) => {
          console.log(JSON.parse(data));
          resolve(JSON.parse(data));
        }, (error) => {
          console.log(error);
          reject(error);
        })
      }else{
        resolve(false);
      }
    });
    return promise;
  }

  // obtener tipo de conexion
  getConnectionType() {
    if(this.platform.is('cordova')){
      let networkState = this.network.type;
      let states = {};
      states[this.network.Connection.UNKNOWN] = 'Unknown connection';
      states[this.network.Connection.ETHERNET] = 'Ethernet connection';
      states[this.network.Connection.WIFI] = 'WiFi connection';
      states[this.network.Connection.CELL_2G] = 'Cell 2G connection';
      states[this.network.Connection.CELL_3G] = 'Cell 3G connection';
      states[this.network.Connection.CELL_4G] = 'Cell 4G connection';
      states[this.network.Connection.CELL] = 'Cell generic connection';
      states[this.network.Connection.NONE] = 'No network connection';
      return states[networkState];
    }else{
      return 'Es web';
    }
  };
  
  // traking de pocisionamiento 
  configureBackgroundGeolocation() {
    let self = this
    if(this.platform.is('cordova')){
      // 1.  Listen to events.
      BackgroundGeolocation.onLocation(location => {
        console.log('[location] - ', location);
      });
  
      BackgroundGeolocation.onMotionChange(event => {
        console.log('[motionchange] - ', event.isMoving, event.location);
      });
  
      BackgroundGeolocation.onHttp(response => {
        console.log('[http] - ', response.success, response.status, response.responseText);
      });
  
      BackgroundGeolocation.onProviderChange(event => {
        console.log('[providerchange] - ', event.enabled, event.status, event.gps);
      });
  
      // 2. Configure the plugin
      BackgroundGeolocation.ready({
        reset: true,
        debug: false,
        logLevel: BackgroundGeolocation.LOG_LEVEL_VERBOSE,
        desiredAccuracy: BackgroundGeolocation.DESIRED_ACCURACY_HIGH,
        distanceFilter: 10,
        url: `${constants.URL_AWSHOST}positions?user_id=${constants.Storage.getItem('user_id')}`,
        method: 'POST',
        autoSync: true,
        stopOnTerminate: false,
        startOnBoot: true
      }, (state) => {
        // Note:  the SDK persists its own state -- it will auto-start itself after being terminated
        // in the enabled-state when configured with stopOnTerminate: false.
        // - The #onEnabledChange event has fired.
        // - The #onConnectivityChange event has fired.
        // - The #onProviderChange has fired (so you can learn the current state of location-services).
        console.log('[ready] BackgroundGeolocation is ready to use');
        if (!state.enabled) {
          // 3. Start the plugin.  In practice, you won't actually be starting the plugin in the #ready callback
          // like this.  More likely, you'll respond to some app or UI which event triggers tracking.  "Starting an order"
          // or "beginning a workout", for example.
          BackgroundGeolocation.start();
        } else {        
          // If configured with stopOnTerminate: false, the plugin has already begun tracking now.        
          // - The #onMotionChange location has been requested.  It will be arriving some time in the near future.        
        }
      });
    }else{
      console.log('Es web');
    }
  }


}
