import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as Constants from '../../util/constants';
import { HelpersProvider } from '../helpers/helpers';
import { Device } from '@ionic-native/device';

@Injectable()
export class SecurityProvider {

  constructor(public http: HttpClient,
              public helper: HelpersProvider,
              private device: Device) {
    console.log('Hello SecurityProvider Provider');
  }
  
  setPanicButton(imei:string, location:string) {
    return new Promise((resolve, reject) => {
        let device_name = ""
        if(this.device.model != null){ 
          device_name = this.device.model 
        }else{ 
          device_name = "Google Chrome" 
        }
        let params = new HttpParams().set('user_id', Constants.Storage.getItem('user_id'))
                                    .set('Imei', imei)
                                    .set('device_name', device_name)
                                    .set('Location', location)
                                    .set('Typo', 'P');
        this.http.post(`${Constants.URL_AWSHOST}PanicButton`, params )
                 .subscribe((data:any) => {
                    if (this.helper.validResponse(data)) {
                      resolve(data.response);
                    } else {
                      reject(data.message);
                    }
                  }, (error:any) => reject("Hubo un problema con la conexión al intentar enviar los datos") )
    });
  }

}
