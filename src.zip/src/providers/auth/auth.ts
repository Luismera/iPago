import { HttpClient  } from '@angular/common/http';
import { Injectable, ChangeDetectorRef } from '@angular/core';
import { HelpersProvider } from '../helpers/helpers';
import * as Constants from '../../util/constants';
//import { BehaviorSubject, Observable } from "rxjs";


export interface User {
  user_id: string;
  user_name: string;
  user_email: string;
  user_imei: string;
  phone_central: string;
  token: string;
}

@Injectable()
export class AuthProvider {

  LOCAL_TOKEN_KEY = 'token'
  USER_ID         = 'user_id'
  INFO_USER       = 'info_user'
  isAuthenticated = false
  authToken = undefined
  public user:any={'user_name':'', 'user_email':''};
  //public user:any ={}; 

  constructor(private http:HttpClient, 
              public helper:HelpersProvider) {
    console.log('Hello AuthProvider Provider');
    this.loadUserCredentials();
  }
  
  login(u:string, p:string) {
    return new Promise((resolve, reject) => {
      this.http.get(Constants.URL_AWSHOST + 'login?username='+u+'&password='+p)             
               .subscribe((data:any)=> {
                 if(this.helper.validResponse(data)){
                    //response info usuario
                    this.storeUserCredentials(data.response);          
                    resolve(data.response);
                 }else{
                    reject(data.message);
                 }
               },(error:any)=> {
                  reject("Hubo un problema con la conexión al intentar enviar los datos");
               })
    }); 
     
  }

  forgot(email:string) {
    return new Promise((resolve, reject) => {
      this.http.get(Constants.URL_AWSHOST + 'ForgotPassword?email='+email)             
               .subscribe((data:any)=> {
                 if(this.helper.validResponse(data)){
                    //response info usuario
                    resolve(data.response);
                 }else{
                    reject(data.message);
                 }
               },(error:any)=> {
                  reject("Hubo un problema con la conexión al intentar enviar los datos");
               })
    }); 
     
  }

  storeUserCredentials(user) {
    //this.user.next(user)
    this.user = user;
    window.localStorage.setItem(this.USER_ID, user.user_id);
    window.localStorage.setItem(this.LOCAL_TOKEN_KEY, user.token);
    window.localStorage.setItem(this.INFO_USER, JSON.stringify(user));
    this.useCredentials(user.token);
  }
  
  useCredentials(token){
    this.isAuthenticated = true;
    this.authToken = token;
    //Set the token as header for your requests!
    //$http.defaults.headers.common.Authorization = this.authToken;
    return
  }

  logout(){
    this.destroyUserCredentials();
    return
  } 

  destroyUserCredentials(){
    //this.user.next({})
    this.user = {'user_name':'', 'user_email':''};
    this.authToken = undefined;
    this.isAuthenticated = false;
    //$http.defaults.headers.common.Authorization = undefined
    window.localStorage.removeItem( this.LOCAL_TOKEN_KEY )
    window.localStorage.removeItem( this.USER_ID )
    window.localStorage.removeItem( this.INFO_USER )
    window.localStorage.clear()  
  }

  loadUserCredentials(){
    let token = window.localStorage.getItem(this.LOCAL_TOKEN_KEY)
    if(token)
      this.useCredentials(token);
      let user = JSON.parse(window.localStorage.getItem(this.INFO_USER))
      //this.user.next( user )
      this.user = user;
    return
  }  

  isUserAuthenticated(){
    return this.isAuthenticated
  }

   


}
