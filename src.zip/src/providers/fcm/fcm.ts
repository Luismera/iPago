import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Firebase } from '@ionic-native/firebase';
import { Platform } from 'ionic-angular';
import { AngularFirestore } from 'angularfire2/firestore';
import * as Constants from '../../util/constants';

@Injectable()
export class FcmProvider {

  constructor(
    private http:HttpClient,
    public firebaseNative: Firebase,
    public afs: AngularFirestore,
    private platform: Platform
  ) {}

  // obtener token del dispocitivo
  async getToken() { 
    let token;
    let platform;

    if (this.platform.is('android')) {
      platform = 'android';
      token = await this.firebaseNative.getToken()
    } 
  
    if (this.platform.is('ios')) {
      platform = 'ios';
      token = await this.firebaseNative.getToken();
      await this.firebaseNative.grantPermission();
    } 
    
    return this.saveTokenToFirestore(token, platform)
  }

  // Guardar token to firestore y en backend
  saveTokenToFirestore(token, platform) {
    console.log(`The token is ${token}`)
    if (!token) return;
    
    let user_id = Constants.Storage.getItem('user_id')
    const devicesRef = this.afs.collection('devices')
    
    const docData = { 
      token,
      userId: user_id,
    }

    this.http.get(`${Constants.URL_AWSHOST}RegisterMobile?dkey=${token}&uid=${user_id}&plataform=${platform}`).subscribe()
  
    return devicesRef.doc(token).set(docData)
  }

  // Escucha los mensajes entrantes de FCM
  listenToNotifications() {
    return this.firebaseNative.onNotificationOpen()
  }

  // Escucha el nuevo token generado
  listenTokenToRefresh() {
    return this.firebaseNative.onTokenRefresh()
  }

}
