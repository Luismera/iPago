import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as Constants from '../../util/constants';
import { HelpersProvider } from '../helpers/helpers';

@Injectable()
export class EventsProvider {

  novedades:any = [];

  constructor(public http: HttpClient, 
              private helper: HelpersProvider) {
    console.log('Hello EventsProvider Provider');
  }

  /*
   * @name getSubcategories
   * @desc obtener las subcategorias de una categoria 
   * @returns retorn un arrray de objetos con categorias
   */
  getSubcategories( idx:string ) {
    return new Promise((resolve, reject) =>{
      /* let params = new HttpParams().set('user_id', '1'); */
      /* http://vivoseguro.sti-atlas.com.co/index.php/api/mobile/Categories?id_main_category=2 */
      this.http.get(`${Constants.URL_AWSHOST}Categories?id_main_category=${idx}` )
                .subscribe((data:any)=> {
                  //console.log(data);
                  if(this.helper.validResponse(data)){
                    resolve(data.response);
                  }else{
                    reject(data.message);
                  }
                }, (error:any)=> {
                  console.log(error);
                  reject("Hubo un problema con la conexión al intentar traer los datos");
                });  
    });
  };

  createNews( data:any ){
    return new Promise((resolve, reject) =>{
      /* let params = new HttpParams().set('user_id', '1'); */
      /* http://vivoseguro.sti-atlas.com.co/index.php/api/mobile/Categories?id_main_category=2 */
      let params = new HttpParams().set('user_id', Constants.Storage.getItem('user_id'))
                                   .set('name', data.title)
                                   .set('description', data.description)
                                   .set('latitud', data.latitud)
                                   .set('longitud', data.longitud)
                                   .set('id_category', data.id_category);
      this.http.post(`${Constants.URL_AWSHOST}Novedad`, params )
                .subscribe((data:any)=> {
                  //console.log(data);
                  if(this.helper.validResponse(data)){
                    resolve(data.response);
                  }else{
                    reject(data.message);
                  }
                }, (error:any)=> {
                  console.log(error);
                  reject("Hubo un problema con la conexión al intentar traer los datos");
                });  
    });
  }

  /*
   * @name getSubcategories
   * @desc obtener las subcategorias de una categoria 
   * @returns retorn un arrray de objetos con categorias
   */
  getNews( own?:boolean ) {
    return new Promise((resolve, reject) =>{
      /* let params = new HttpParams().set('user_id', '1'); */
      /* http://vivoseguro.sti-atlas.com.co/index.php/api/mobile/GetNews?user_id=2 
          http://localhost/vivoseguro/public/dev_backend.php/api/mobile/GetNews
      */
      let query = `${Constants.URL_AWSHOST}GetNews`
      if(own){
        query = `${Constants.URL_AWSHOST}GetNews?user_id=${Constants.Storage.getItem('user_id')}`       
      }
      this.http.get(query)
                .subscribe((data:any)=> {
                  //console.log(data);
                  if(this.helper.validResponse(data)){
                    this.novedades = data.response
                    resolve(data.response);
                  }else{
                    this.novedades = []
                    reject(data.message);
                  }
                },(error:any)=> {
                   console.log(error);
                   reject("Hubo un problema con la conexión al intentar traer los datos");
                });  
    });
  };


}
