import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HelpersProvider } from '../helpers/helpers';
import * as Constants from '../../util/constants';

/*
  Generated class for the SystemProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SystemProvider {

  constructor(public http: HttpClient, private helper:HelpersProvider) {
    console.log('Hello SystemProvider Provider');
  }

  getUserActivities(){
    return new Promise((resolve, reject)=>{
      /*let params = new HttpParams()
         .set('user_id', '1');*/
      this.http.get(`${Constants.URL_AWSHOST}UserAccounts?user_id=${Constants.Storage.getItem('user_id')}` )
                .subscribe((data:any)=> {
                  console.log(data);
                  if(this.helper.validResponse(data)){

                     resolve(data.response);
                  }else{
                     reject(data.message);
                  }
                },(error:any)=> {
                   console.log(error);
                   reject("Hubo un problema con la conexión al intentar traer los datos");
                });  
    });
  }
  
}
