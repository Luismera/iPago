var exec = require('cordova/exec');

function CountDownBackground() {
	console.log("CountDownBackground.js: is created");
	this.setConfig = (config, success, error) => {
		exec(success, error, "CountDownBackground", 'setConfig', [config]);
	}

	// GET STATUS //
	this.getStatus = (success, error) => {
		exec(success, error, "CountDownBackground", 'getStatus', []);
	}

	// STOP SERVICE //
	this.stop = (success, error) => {
		exec(success, error, "CountDownBackground", 'stop', []);
	}

	// GET SERVICE RUNNING //
	this.isServiceRunning =  (success, error) => {
		exec(success, error, "CountDownBackground", 'isServiceRunning', []);
	}


	this.onTimeNotificationCallback = (payload) => {
		console.log(payload);
	}

	this.onTimeNotification =  (callback, success, error) => {
		this.onTimeNotificationCallback = callback;
		exec(success, error, "CountDownBackground", 'registerTimeNotification', []);
	}

}

exec((result) => { 
	console.log("CountDownBackground Ready OK") 
}, (result) => { 
	console.log("CountDownBackground Ready ERROR") 
}, "CountDownBackground",'ready',[]);

var CountDownBackground = new CountDownBackground();
module.exports = CountDownBackground;
