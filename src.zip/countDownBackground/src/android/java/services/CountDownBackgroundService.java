package cordova.plugin.count.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

import cordova.plugin.count.plugins.CountDownBackgroundPlugin;
import com.tc.atlasvivoseguropro.R;

public class CountDownBackgroundService extends Service {

    private final String TAG = this.getClass().getSimpleName();
    private int id = 1;
    private boolean running = false;
    private CountDownTimer countDownTimer;
    private Notification notification;
    private NotificationManager notificationManager;
    private Long tiempo;
    private Boolean showNotification = false;
    private Ringtone ringtone;
    private Vibrator vibrate;
    private Handler handler;
    private Runnable runnable;
    private final String channelNameLow = "Channel notification low priority";
    private final String channelNameHigh = "Channel notification high priority";
    private final String channelIdHigh = "channel-notification-high";
    private final String channelIdLow = "channel-notification-low";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel notificationChannelLow = new NotificationChannel(channelIdLow, channelNameLow, NotificationManager.IMPORTANCE_HIGH);
            notificationChannelLow.setSound(null, null);
            notificationChannelLow.setVibrationPattern(null);
            notificationChannelLow.enableVibration(false);
            notificationChannelLow.enableLights(true);
            NotificationChannel notificationChannelHigh = new NotificationChannel(channelIdHigh, channelNameHigh, NotificationManager.IMPORTANCE_HIGH);
            notificationChannelLow.enableVibration(true);
            notificationChannelLow.enableLights(true);
            notificationManager.createNotificationChannel( notificationChannelHigh);
            notificationManager.createNotificationChannel( notificationChannelLow);
        }
    }

    @Override
    public void onDestroy() {
        try {
            Log.e(TAG, "onDestroy: ");
            if (running) {
                running = false;
                stopForeground(true);
                if (this.countDownTimer != null) {
                    this.countDownTimer.cancel();
                    this.countDownTimer = null;
                }
                notificationManager.cancel(2);
                if (this.handler != null && this.runnable != null){
                    handler.removeCallbacks(runnable);
                    handler = null;
                    runnable = null;
                }
                if (this.vibrate != null){
                    this.vibrate.cancel();
                    this.vibrate = null;
                }
                if (this.ringtone != null && this.ringtone.isPlaying()){
                    this.ringtone.stop();
                    this.ringtone = null;
                }
                CountDownBackgroundPlugin.sendTimeNotification(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (intent != null && !running) {
                try {
                    String action = intent.getAction();
                    if (action != null) {
                        switch (action) {
                            case "startService":
                                String url = null;
                                if (intent.hasExtra("url")){
                                    url = intent.getStringExtra("url");
                                }
                                String method = null;
                                if (intent.hasExtra("method")){
                                    method = intent.getStringExtra("method");
                                }
                                Long imei = null;
                                if (intent.hasExtra("imei")){
                                    imei = intent.getLongExtra("imei",0);
                                }
                                Long user_id = null;
                                if (intent.hasExtra("user_id")){
                                    user_id = intent.getLongExtra("user_id",0);
                                }
                                Long time = null;
                                if (intent.hasExtra("time")){
                                    time = intent.getLongExtra("time",0);
                                }
                                String type = null;
                                if (intent.hasExtra("type")){
                                    type = intent.getStringExtra("type");
                                }
                                String location = null;
                                if (intent.hasExtra("location")){
                                    location = intent.getStringExtra("location");
                                }
                                this.start(url, method, imei, user_id, time, type, location);
                                break;
                            case "stopService":
                                stopSelf();
                                break;
                            default:
                                Log.e(TAG, "onStartCommand: parametro invalido");
                                stopSelf();
                                break;
                        }

                    } else {
                        Log.e(TAG, "onStartCommand: action null");
                        stopSelf();
                    }
                } catch (Exception e) {
                    Log.e("Onstartcommand", "onStartCommand: ", e);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Service.START_REDELIVER_INTENT;
    }

    private void start(String url, String method, Long imei, Long user_id, Long time, String type, String location) {
        try {
            if (!running) {
                running = true;
                tiempo = time;
                notification = createNotificationRunning();
                startForeground(id, notification);
                Log.e(TAG, "start: tiempo: " + tiempo);
                this.countDownTimer = new CountDownTimer(tiempo, 1000) {
                    @Override
                    public void onTick(long l) {
                        tiempo = l;
                        notification = createNotificationRunning();
                        notificationManager.notify(id, notification);
                        CountDownBackgroundPlugin.sendTimeNotification(tiempo);
                        if (tiempo <= (61 * 1000) && !showNotification) {
                            initAlarm();
                        }
                    }

                    @Override
                    public void onFinish() {
                        try {
                            StringBuilder builder = new StringBuilder();
                            if (imei != null){
                                builder.append("Imei="+imei);
                            }
                            if (user_id != null){
                                builder.append("&user_id="+user_id);
                            }
                            if (type != null){
                                builder.append("&Typo="+type);
                            }
                            if (location != null){
                                builder.append("&Location="+location);
                            }
                            Log.e(TAG, "onFinish: url: "+url);
                            Log.e(TAG, "onFinish: stringBuilder"+builder.toString());
                            sendRequest(url+"?"+builder.toString(), (method.trim().equals("POST")) ? Request.Method.POST : Request.Method.GET,null);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                };
                this.countDownTimer.start();
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    private Notification createNotificationRunning() {
        String pkgName = this.getPackageName();
        Intent intent = this.getPackageManager().getLaunchIntentForPackage(pkgName);
        // The PendingIntent to launch our activity if the user selects this
        // notification
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addNextIntent(intent);
        PendingIntent contentIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, channelIdHigh)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.drawable.notification))
                .setSmallIcon(R.drawable.notification) // the
                // status icon
                .setVibrate(null)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis()) // the time stamp
                .setContentTitle("Se ha iniciado el servicio.") // the label of the entry
                .setOnlyAlertOnce(true)
                .setLights(Color.BLUE, 1000, 1000)
                .setContentText("Tiempo restante: " + new SimpleDateFormat("mm:ss").format(new Date(tiempo))) // the contents
                // of the
                // entry
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setAutoCancel(false)
                .build();
    }


    private void sendNotification() {
        Notification información = new NotificationCompat.Builder(this, channelIdLow)
                .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.drawable.notification))
                .setSmallIcon(R.drawable.notification) // the
                // status icon
                .setVibrate(null)
                .setSound(null)
                .setPriority(Notification.PRIORITY_LOW)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis()) // the time stamp
                .setContentTitle("Información") // the label of the entry
                .setOnlyAlertOnce(true)
                .setLights(Color.GREEN, 1000, 1000)
                .setContentText("Se enviará la señal de pánico") // the contents
                // of the
                // entry
                //.setContentIntent(contentIntent)
                .setOngoing(false)
                .setAutoCancel(true)
                .build();
        notificationManager.notify(2,información);
    }

    private void initAlarm(){
        this.showNotification = true;
        long[] pattern = {0, 500, 500};
        this.vibrate = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        this.ringtone = RingtoneManager.getRingtone(this, uriFromRaw("notification"));
        if (ringtone != null) {
            ringtone.play();
        }
        if (this.vibrate != null){
            this.vibrate.vibrate(pattern, 0);
        }
        sendNotification();
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                if (vibrate != null){
                    vibrate.cancel();
                    vibrate = null;
                }
                if (ringtone != null && ringtone.isPlaying()){
                    ringtone.stop();
                    ringtone = null;
                }
                handler = null;
            }
        };
        handler.postDelayed(runnable, 5*1000);
    }

    private void sendRequest(String url, Integer method, JSONObject jsonObject) {
        JsonObjectRequest jsonRequest = new JsonObjectRequest
                (method, url, jsonObject, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // the response is already constructed as a JSONObject!
                        try {
                            Log.e(TAG, "onResponse: "+response.toString());
                            stopSelf();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        stopSelf();
                    }
                });
        Volley.newRequestQueue(this).add(jsonRequest);
    }

    private Uri uriFromRaw(String name) {
        int resId = this.getResources().getIdentifier(name, "raw", this.getPackageName());
        return Uri.parse("android.resource://" + this.getPackageName() + "/" + resId);
    }
}