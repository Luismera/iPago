package cordova.plugin.count.plugins;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cordova.plugin.count.services.CountDownBackgroundService;

/**
 * This class echoes a string called from JavaScript.
 */
public class CountDownBackgroundPlugin extends CordovaPlugin {

    private static CordovaWebView gWebView;
    private static final String TAG = CountDownBackgroundPlugin.class.getSimpleName();
    private static Long lastTimeNotification = null;
    private static Boolean notificationCallBackReady = false;

    public CountDownBackgroundPlugin() {
    }

    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        gWebView = webView;
        Log.d(TAG, "==> CountDownBackgroundPlugin initialize");
        this.notificationCallBackReady = false;
    }

    @Override
    protected void pluginInitialize() {
        // addWindowFlags(cordova.getActivity());
    }

    @Override
    public boolean execute(final String action, final JSONArray args, final CallbackContext callbackContext)
            throws JSONException {
        try {
            final Activity activity = this.cordova.getActivity();
            // READY //
            switch (action) {
                case "ready":
                    //
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                callbackContext.success();
                            } catch (Exception e) {
                                e.printStackTrace();
                                callbackContext.error(e.getMessage());
                            }
                        }
                    });
                    break;
                // GET TOKEN //
                case "getStatus":
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                if (lastTimeNotification != null) {
                                    callbackContext.success(Long.toString(lastTimeNotification));
                                } else {
                                    callbackContext.success("null");
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                callbackContext.error(e.getMessage());
                            }
                        }
                    });
                    break;
                // NOTIFICATION CALLBACK REGISTER //
                case "isServiceRunning":
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                callbackContext.success(Boolean.toString(isMyServiceRunning(CountDownBackgroundService.class)));
                            } catch (Exception e) {
                                e.printStackTrace();
                                callbackContext.error(e.getMessage());
                            }
                        }
                    });
                    break;
                // NOTIFICATION CALLBACK REGISTER //
                case "setConfig":
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                if (!isMyServiceRunning(CountDownBackgroundService.class)) {
                                    startService(args.getJSONObject(0), callbackContext);
                                } else {
                                    callbackContext.error("El servicio se encuentra activo.");
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                callbackContext.error(e.getMessage());
                            }
                        }
                    });
                    break;
                case "stop":
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                if (isMyServiceRunning(CountDownBackgroundService.class)) {
                                    stopService(callbackContext);
                                } else {
                                    callbackContext.error("El servicio no se encuentra activo.");
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                callbackContext.error(e.getMessage());
                            }
                        }
                    });
                    break;
                case "registerTimeNotification":
                    this.notificationCallBackReady = true;
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                if (lastTimeNotification != null) {
                                    sendTimeNotification(lastTimeNotification);
                                } else {
                                    callbackContext.success();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                callbackContext.error(e.getMessage());
                            }
                        }
                    });
                    break;
                default:
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                callbackContext.error("Metodo no encontrado");
                            } catch (Exception e) {
                                e.printStackTrace();
                                callbackContext.error(e.getMessage());
                            }
                        }
                    });
                    return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private Activity getApp() {
        return cordova.getActivity();
    }

    private void startService(JSONObject jsonObject, CallbackContext callbackContext) {
        try {
            lastTimeNotification = null;
            Log.e(TAG, "startService: " + jsonObject);

            if (!jsonObject.has("url")) {
                callbackContext.error("Parametro url requerido.");
            } else if (!jsonObject.has("method")) {
                callbackContext.error("Parametro method requerido.");
            } else if (!jsonObject.has("imei")) {
                callbackContext.error("Parametro imei requerido.");
            } else if (!jsonObject.has("user_id")) {
                callbackContext.error("Parametro user_id requerido.");
            } else if (!jsonObject.has("time")) {
                callbackContext.error("Parametro time requerido.");
            } else if (!jsonObject.has("type")) {
                callbackContext.error("Parametro type requerido.");
            } else if (!jsonObject.has("location")) {
                callbackContext.error("Parametro location requerido.");
            }
            else{
                Intent intent = new Intent(getApp(), CountDownBackgroundService.class);
                intent.setAction("startService");
                if (jsonObject.has("url")) {
                    intent.putExtra("url", jsonObject.getString("url"));
                }
                if (jsonObject.has("method")) {
                    intent.putExtra("method", jsonObject.getString("method"));
                }
                if (jsonObject.has("imei")) {
                    intent.putExtra("imei", jsonObject.getLong("imei"));
                }
                if (jsonObject.has("user_id")) {
                    intent.putExtra("user_id", jsonObject.getLong("user_id"));
                }
                if (jsonObject.has("time")) {
                    intent.putExtra("time", jsonObject.getLong("time"));
                }
                if (jsonObject.has("type")) {
                    intent.putExtra("type", jsonObject.getString("type"));
                }
                if (jsonObject.has("location")) {
                    intent.putExtra("location", jsonObject.getString("location"));
                }
                Log.e(TAG, "startService: "+jsonObject.toString());
                getApp().startService(intent);
                PluginResult pluginResult = new PluginResult(PluginResult.Status.OK, "Se ha iniciado el servicio");
                pluginResult.setKeepCallback(false);
                callbackContext.sendPluginResult(pluginResult);
            }
        } catch (Exception e) {
            e.printStackTrace();
            PluginResult pluginResult = new PluginResult(PluginResult.Status.ERROR, "No se ha iniciado el servicio");
            pluginResult.setKeepCallback(false);
            callbackContext.sendPluginResult(pluginResult);
        }
    }

    /**
     * Bind the activity to a background service and put them into foreground state.
     */
    private void stopService(CallbackContext callbackContext) {
        try {
            lastTimeNotification = null;
            Intent intent = new Intent(getApp(), CountDownBackgroundService.class);
            intent.setAction("stopService");
            getApp().stopService(intent);
            PluginResult pluginResult = new PluginResult(PluginResult.Status.OK, "Se ha parado el servicio");
            pluginResult.setKeepCallback(false);
            callbackContext.sendPluginResult(pluginResult);
        } catch (Exception e) {
            e.printStackTrace();
            PluginResult pluginResult = new PluginResult(PluginResult.Status.ERROR, "Error al parar el servicio");
            pluginResult.setKeepCallback(false);
            callbackContext.sendPluginResult(pluginResult);
        }
    }

    public static void sendTimeNotification(Long time) {
        try {
            if (time != null){
                String onTimeNotificationCallBack = "window.cordova.plugins.countDownBackground.onTimeNotificationCallback";
                String callBack = "javascript:" + onTimeNotificationCallBack + "(" + Long.toString(time) + ")";
                if (notificationCallBackReady && gWebView != null) {
                    gWebView.sendJavascript(callBack);
                }
            }
            lastTimeNotification = time;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        try {
            gWebView = null;
            lastTimeNotification = null;
            notificationCallBackReady = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getApp().getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

}